/*
 * E_TCPAssignment.cpp
 *
 *  Created on: 2014. 11. 20.
 *      Author: 근홍
 */


#include <E/E_Common.hpp>
#include <E/Networking/E_Host.hpp>
#include <E/Networking/E_Networking.hpp>
#include <cerrno>
#include <E/Networking/E_Packet.hpp>
#include <E/Networking/E_NetworkUtil.hpp>
#include "TCPAssignment.hpp"

namespace E
{

TCPAssignment::TCPAssignment(Host* host) : HostModule("TCP", host),
		NetworkModule(this->getHostModuleName(), host->getNetworkSystem()),
		SystemCallInterface(AF_INET, IPPROTO_TCP, host),
		NetworkLog(host->getNetworkSystem()),
		TimerModule(host->getSystem())
{

}

TCPAssignment::~TCPAssignment()
{

}

void TCPAssignment::initialize()
{

}

void TCPAssignment::finalize()
{

}

void TCPAssignment::systemCallback(UUID syscallUUID, int pid, const SystemCallParameter& param)
{
	switch(param.syscallNumber)
	{
	case SOCKET:
		syscall_socket(syscallUUID, pid, param.param1_int, param.param2_int);
		break;
	case CLOSE:
		this->syscall_close(syscallUUID, pid, param.param1_int);
		break;
	case READ:
		this->syscall_read(syscallUUID, pid, param.param1_int, param.param2_ptr, param.param3_int);
		break;
	case WRITE:
		this->syscall_write(syscallUUID, pid, param.param1_int, param.param2_ptr, param.param3_int);
		break;
	case CONNECT:
		this->syscall_connect(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr*>(param.param2_ptr), (socklen_t)param.param3_int);
		break;
	case LISTEN:
		this->syscall_listen(syscallUUID, pid, param.param1_int, param.param2_int);
		break;
	case ACCEPT:
		this->syscall_accept(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr*>(param.param2_ptr),
				static_cast<socklen_t*>(param.param3_ptr));
		break;
	case BIND:
		this->syscall_bind(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr *>(param.param2_ptr),
				(socklen_t) param.param3_int);
		break;
	case GETSOCKNAME:
		this->syscall_getsockname(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr *>(param.param2_ptr),
				static_cast<socklen_t*>(param.param3_ptr));
		break;
	case GETPEERNAME:
		this->syscall_getpeername(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr *>(param.param2_ptr),
				static_cast<socklen_t*>(param.param3_ptr));
		break;
	default:
		assert(0);
	}
}

void TCPAssignment::packetArrived(std::string fromModule, Packet* packet)
{
	uint32_t src_ip;
	uint32_t dst_ip;
	uint16_t src_port;
	uint16_t dst_port;
	uint32_t seqNumber;
	uint32_t ackNumber;
	uint long head_len;
	uint long flag;
	uint16_t rwnd;
	uint16_t checksum;
	uint16_t urgent;

	// Get header from packet arriving
	packet->readData(0, &src_ip, 4);
	packet->readData(4, &dst_ip, 4);
	packet->readData(8, &src_port, 2);
	packet->readData(10, &dst_port, 2);
	packet->readData(12, &seqNumber, 4);
	packet->readData(16, &ackNumber, 4);
	packet->readData(20, &head_len, 1);
	packet->readData(21, &flag, 1);
	packet->readData(22, &rwnd, 2);
	packet->readData(24, &checksum, 2);
	packet->readData(26, &urgent, 2);

	// Get payload
	void* payload;
	packet->readData(28, &payload, (sizeof(packet)-(head_len)));

	// Send acknowledgement
	hdr *header = new hdr();
	header->src_ip = dst_ip;
	header->dst_ip = src_ip;
	header->src_port = dst_port;
	header->dst_port = src_port;
	header->seqNumber = ackNumber;
	header->ackNumber = seqNumber + MSS;
	header->head_len = head_len;
	header->flag = flag;
	header->rwnd = rwnd;
	header->checksum = checksum;
	header->urgent = urgent;

	this->writePacket(header, payload, sizeof(packet));
}

void TCPAssignment::timerCallback(void* payload)
{

}

// Handlers for syscall
void TCPAssignment::syscall_socket(UUID syscallUUID, int pid, int domain, int type)
{
	int socket;
	socket=this->createFileDescriptor(pid);
	this->returnSystemCall(syscallUUID,socket);
}

void TCPAssignment::syscall_close(UUID syscallUUID, int pid, int socket)
{
    std::list<struct sock_segmt>::iterator iter;
    iter = this->find_sock_segmt_by(socket);

    if (iter!=this->sock_segmt_list.end())
        this->sock_segmt_list.erase(iter);
	this->removeFileDescriptor(pid,socket);
	this->returnSystemCall(syscallUUID,0);
}

void TCPAssignment::syscall_connect(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t address_len)
{
	uint32_t src_ip, dest_ip;
	uint16_t src_port, dest_port;
	struct sockaddr_in *address_in = (struct sockaddr_in *)address;
	std::list<struct sock_segmt>::iterator iter = this->find_sock_segmt_by(socket);

	dest_ip = address_in->sin_addr.s_addr;
	dest_port = address_in->sin_port;
	src_ip = (*iter).addr;
	src_port = (*iter).port;

	// TODO: Put dest_ip, dest_port, src_ip, src_port into TCP header
	this->returnSystemCall(syscallUUID,0);
}

void TCPAssignment::syscall_listen(UUID syscallUUID, int pid, int socket, int backlog)
{
	std::list<struct sock_segmt> sock_segmt_list = this->sock_segmt_list;
	std::list<struct sock_segmt>::iterator iter;
    iter = this->find_sock_segmt_by(socket);

    if (sock_segmt_list.empty() || iter==sock_segmt_list.end())	// not found
    	this->returnSystemCall(syscallUUID,-1);
    this->returnSystemCall(syscallUUID,0);
}

void TCPAssignment::syscall_accept(UUID syscallUUID, int pid, int socket, struct sockaddr *address, socklen_t *address_len)
{
	std::list<struct sock_segmt>::iterator iter;
	iter = this->find_sock_segmt_by(socket);
	if (sock_segmt_list.empty() || iter==sock_segmt_list.end()) {
		this->returnSystemCall(syscallUUID,-1);
	} else {
		// consume from stack
		this->sock_segmt_list.erase(iter);
		// Create new file descriptor for incoming connection
		socket=this->createFileDescriptor(pid);
		this->returnSystemCall(syscallUUID,socket);
	}
}

void TCPAssignment::syscall_bind(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t address_len)
{
    sock_segmt new_sock;
    struct sockaddr_in* sock_info = (sockaddr_in *)address;
    new_sock.socket = socket;
    new_sock.addr = sock_info->sin_addr.s_addr;
    new_sock.port = sock_info->sin_port;

    if (this->overlap(new_sock)){
        this->returnSystemCall(syscallUUID,-1);
    } else {
        this->sock_segmt_list.push_back(new_sock);	
        this->returnSystemCall(syscallUUID,0);
    }
}

void TCPAssignment::syscall_getsockname(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t *address_len)
{
    struct sockaddr_in *address_in = (struct sockaddr_in *)address;
    std::list<struct sock_segmt>::iterator iter = this->find_sock_segmt_by(socket);
    address_in->sin_family = AF_INET;
    address_in->sin_addr.s_addr = (*iter).addr;
    address_in->sin_port = (*iter).port;
    this->returnSystemCall(syscallUUID, 0);
}

void TCPAssignment::syscall_getpeername(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t *address_len)
{
    struct sockaddr_in *address_in = (struct sockaddr_in *)address;
    std::list<struct sock_segmt>::iterator iter = this->find_sock_segmt_by(socket);
    address_in->sin_family = AF_INET;
    address_in->sin_addr.s_addr = (*iter).addr;
    address_in->sin_port = (*iter).port;
    this->returnSystemCall(syscallUUID, 0);
}

// KENS#2
void TCPAssignment::syscall_write(UUID syscallUUID, int pid, int socket, void *payload, size_t size)
{
	struct sock_segmt* mSock;
	bool found = this->find_sock_segmt(pid, socket, mSock);
	if(found == false)
		this->returnSystemCall(syscallUUID, -1);
	else {
		int max_wnd = std::min(mSock->rwnd, mSock->cwnd);

		if(size >= max_wnd) {
			// Send up to buffer size, queue remaining payload for next write call
			void *payload_tosend; 
			memcpy(&payload_tosend, &payload, max_wnd);
			void *payload_temp = &payload;
			memcpy(&payload, &payload_temp + max_wnd, size-max_wnd);

			struct hdr *hdr;
			hdr = &(mSock->hdr);

			// Send segment by segment
			for(int i=0; i<=sizeof(payload_tosend); i+=MSS) {
				int segmt_size = sizeof(payload_tosend+i)>MSS ? MSS : sizeof(payload_tosend+i);
				time_t start_time = time(NULL);
				writePacket(hdr, payload_tosend+i, segmt_size);
				time_t end_time = time(NULL);
				time_t rtt = end_time - start_time;

				// TODO: Check acknowledgement
				bool nack = false;

				if (nack)
					mSock->dupAck += 1;

				// Check packet loss
				if ((mSock->dupAck) >= 3) {				// duplicated acknowledgement -> fast retransmit
					updateCongestionControls(mSock, rtt, true);
					syscall_write(syscallUUID, pid, socket, payload, size);
				} else if (rtt > TIMEOUT || nack) {		// resend
					updateCongestionControls(mSock, rtt, false);
					syscall_write(syscallUUID, pid, socket, payload, size);
				} else {
					// Update sequence number, ack number
					updateHeader(hdr, segmt_size);
					
					// Calculate RTT and update buffer, rwnd, cwnd
					updateCongestionControls(mSock, rtt, false);
				}
			}
			this->returnSystemCall(syscallUUID, 0);
		} else {
			// Send all data
			struct hdr *hdr;
			hdr = &(mSock->hdr);
			time_t start_time = time(NULL);
			writePacket(hdr, payload, size);
			time_t end_time = time(NULL);
			time_t rtt = end_time - start_time;

			// TODO: Check acknowledgement
			bool nack = false;

			if (nack)
				mSock->dupAck += 1;

			// Check packet loss
			if ((mSock->dupAck) >= 3) {				// duplicated acknowledgement -> fast retransmit
				updateCongestionControls(mSock, rtt, true);
				syscall_write(syscallUUID, pid, socket, payload, size);
			} else if (rtt > TIMEOUT || nack) {		// resend
				updateCongestionControls(mSock, rtt, false);
				syscall_write(syscallUUID, pid, socket, payload, size);
			} else {
				// Update sequence number, ack number
				updateHeader(hdr, size);
				// Calculate RTT and update buffer, rwnd, cwnd
				updateCongestionControls(mSock, rtt, false);
			}

			/*// Update sequence number, ack number
			updateHeader(hdr, size);

			// Calculate RTT and update buffer, rwnd, cwnd
			updateCongestionControls(mSock, rtt, false);*/
			this->returnSystemCall(syscallUUID, 0);
		}
	}
}


void TCPAssignment::syscall_read(UUID syscallUUID, int pid, int socket, void *payload, size_t size) 
{
	struct sock_segmt* mSock;
	bool found = this->find_sock_segmt(pid, socket, mSock);
	if(found == false)
		this->returnSystemCall(syscallUUID, -1);
	else {
		// Read all data
		struct hdr *hdr;
		hdr = &(mSock->hdr);
		readPacket(hdr, payload, size);

		// Update sequence number, ack number
		updateHeader(hdr, size);
		this->returnSystemCall(syscallUUID, 0);
	}
}


// Helper methods for syscall
std::list<struct sock_segmt>::iterator TCPAssignment::find_sock_segmt_by(int socket)
{
    std::list<struct sock_segmt> sock_segmt_list = this->sock_segmt_list;
    std::list<struct sock_segmt>::iterator iter;

    for(iter=this->sock_segmt_list.begin(); iter != this->sock_segmt_list.end(); ++iter){
        if ((*iter).socket==socket){
            return iter;
        }
    }
    return this->sock_segmt_list.end();
}

bool TCPAssignment::find_sock_segmt(int pid, int socket, struct sock_segmt* mSock)
{
	std::list<struct sock_segmt> sock_segmt_list = this->sock_segmt_list;
	for(auto i=sock_segmt_list.begin(); i!=sock_segmt_list.end(); i++) {
		if((*i).pid == pid && (*i).socket == socket) {
			*mSock = *i;
			return true;
		}
	}
	return false;
}

bool TCPAssignment::overlap(sock_segmt new_sock)
{
	std::list<struct sock_segmt> sock_segmt_list = this->sock_segmt_list;
    std::list<struct sock_segmt>::iterator iter;

    for(iter=sock_segmt_list.begin(); iter != sock_segmt_list.end(); ++iter){
        bool check_socket = ((*iter).socket == new_sock.socket);
        bool check_sp_ip = ((*iter).addr == 0 || new_sock.addr == 0);
        bool same_ip_port = (((*iter).addr == new_sock.addr) && ((*iter).port == new_sock.port));
        if(check_socket || check_sp_ip || same_ip_port)
            return true;
    }
    return false;
}

// KENS#2
void TCPAssignment::writePacket(struct hdr *hdr, void *payload, size_t size = 0)
{
	Packet* mPacket = this->allocatePacket(sizeof(struct hdr) + size);

	mPacket->writeData(0, hdr, sizeof(struct hdr));
	mPacket->writeData(sizeof(struct hdr), payload, size);

	this->sendPacket("IPv4", mPacket);
}

void TCPAssignment::readPacket(struct hdr *hdr, void *payload, size_t size = 0)
{
	Packet* mPacket = this->allocatePacket(sizeof(struct hdr) + size);

	mPacket->readData(0, hdr, sizeof(struct hdr));
	mPacket->readData(sizeof(struct hdr), payload, size);

	this->packetArrived("IPv4", mPacket);
}

void TCPAssignment::updateHeader(struct hdr *hdr, size_t size)
{
	hdr->seqNumber += size;
	hdr->ackNumber += size;
}

void TCPAssignment::updateCongestionControls(struct sock_segmt *sock, time_t rtt, bool fast)
{
	sock->rtt = rtt;
	time_t delay = rtt + 4*(sock->devtt);
	this->addTimer(NULL, delay);

	// Update rwnd and buffer
	unsigned written_bits = WRITE_SPEED*rtt;
	int new_buffer = sock->buffer - written_bits;
	sock->buffer = (new_buffer>0) ? new_buffer : 0;
	sock->rwnd = MSS - sock->buffer;
	
	// Update cwnd based on Reno
	if(fast) {											// Fast recovery
		sock->ssthresh = sock->cwnd /2;
		sock->cwnd = sock->ssthresh + 3*MSS;
		sock->dupAck = 0;
	} else {
		if(rtt >= TIMEOUT) {							// Slow start
			sock->ssthresh = sock->cwnd / 2;
			sock->cwnd = MSS;
		}
		
		if (sock->cwnd < sock->ssthresh) {				// Slow start
			sock->cwnd *= 2;
		} else if (sock->cwnd >= sock->ssthresh) {		// Congestion Avoidance
			sock->cwnd += MSS;
		}	 
	}
}

}
