/*
 * E_TCPAssignment.cpp
 *
 *  Created on: 2014. 11. 20.
 *      Author: 근홍
 */


#include <E/E_Common.hpp>
#include <E/Networking/E_Host.hpp>
#include <E/Networking/E_Networking.hpp>
#include <cerrno>
#include <E/Networking/E_Packet.hpp>
#include <E/Networking/E_NetworkUtil.hpp>
#include "TCPAssignment.hpp"

namespace E
{

TCPAssignment::TCPAssignment(Host* host) : HostModule("TCP", host),
		NetworkModule(this->getHostModuleName(), host->getNetworkSystem()),
		SystemCallInterface(AF_INET, IPPROTO_TCP, host),
		NetworkLog(host->getNetworkSystem()),
		TimerModule(host->getSystem())
{

}

TCPAssignment::~TCPAssignment()
{

}

void TCPAssignment::initialize()
{

}

void TCPAssignment::finalize()
{

}

void TCPAssignment::systemCallback(UUID syscallUUID, int pid, const SystemCallParameter& param)
{
	switch(param.syscallNumber)
	{
	case SOCKET:
		syscall_socket(syscallUUID, pid, param.param1_int, param.param2_int);
		break;
	case CLOSE:
		this->syscall_close(syscallUUID, pid, param.param1_int);
		break;
	case READ:
		//this->syscall_read(syscallUUID, pid, param.param1_int, param.param2_ptr, param.param3_int);
		break;
	case WRITE:
		//this->syscall_write(syscallUUID, pid, param.param1_int, param.param2_ptr, param.param3_int);
		break;
	case CONNECT:
		this->syscall_connect(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr*>(param.param2_ptr), (socklen_t)param.param3_int);
		break;
	case LISTEN:
		this->syscall_listen(syscallUUID, pid, param.param1_int, param.param2_int);
		break;
	case ACCEPT:
		this->syscall_accept(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr*>(param.param2_ptr),
				static_cast<socklen_t*>(param.param3_ptr));
		break;
	case BIND:
		this->syscall_bind(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr *>(param.param2_ptr),
				(socklen_t) param.param3_int);
		break;
	case GETSOCKNAME:
		this->syscall_getsockname(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr *>(param.param2_ptr),
				static_cast<socklen_t*>(param.param3_ptr));
		break;
	case GETPEERNAME:
		this->syscall_getpeername(syscallUUID, pid, param.param1_int,
				static_cast<struct sockaddr *>(param.param2_ptr),
				static_cast<socklen_t*>(param.param3_ptr));
		break;
	default:
		assert(0);
	}
}

void TCPAssignment::packetArrived(std::string fromModule, Packet* packet)
{

}

void TCPAssignment::timerCallback(void* payload)
{

}

// Handlers for syscall
void TCPAssignment::syscall_socket(UUID syscallUUID, int pid, int domain, int type)
{
	int socket;
	socket=this->createFileDescriptor(pid);
	this->returnSystemCall(syscallUUID,socket);
}

void TCPAssignment::syscall_close(UUID syscallUUID, int pid, int socket)
{
    std::list<struct sock_segmt>::iterator iter;
    iter = this->find_sock_segmt_by(socket);

    if (iter!=this->sock_segmt_list.end())
        this->sock_segmt_list.erase(iter);
	this->removeFileDescriptor(pid,socket);
	this->returnSystemCall(syscallUUID,0);
}

void TCPAssignment::syscall_connect(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t address_len)
{
	uint32_t src_ip, dest_ip;
	uint16_t src_port, dest_port;
	struct sockaddr_in *address_in = (struct sockaddr_in *)address;
	std::list<struct sock_segmt>::iterator iter = this->find_sock_segmt_by(socket);

	dest_ip = address_in->sin_addr.s_addr;
	dest_port = address_in->sin_port;
	src_ip = (*iter).addr;
	src_port = (*iter).port;

	// TODO: Put dest_ip, dest_port, src_ip, src_port into TCP header
	this->returnSystemCall(syscallUUID,0);
}

void TCPAssignment::syscall_listen(UUID syscallUUID, int pid, int socket, int backlog)
{
	std::list<struct sock_segmt> sock_segmt_list = this->sock_segmt_list;
	std::list<struct sock_segmt>::iterator iter;
    iter = this->find_sock_segmt_by(socket);

    if (sock_segmt_list.empty() || iter==sock_segmt_list.end())	// not found
    	this->returnSystemCall(syscallUUID,-1);
    this->returnSystemCall(syscallUUID,0);
}

void TCPAssignment::syscall_accept(UUID syscallUUID, int pid, int socket, struct sockaddr *address, socklen_t *address_len)
{
	std::list<struct sock_segmt>::iterator iter;
	iter = this->find_sock_segmt_by(socket);
	if (sock_segmt_list.empty() || iter==sock_segmt_list.end()) {
		this->returnSystemCall(syscallUUID,-1);
	} else {
		// consume from stack
		this->sock_segmt_list.erase(iter);
		// Create new file descriptor for incoming connection
		socket=this->createFileDescriptor(pid);
		this->returnSystemCall(syscallUUID,socket);
	}
}

void TCPAssignment::syscall_bind(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t address_len)
{
    sock_segmt new_sock;
    struct sockaddr_in* sock_info = (sockaddr_in *)address;
    new_sock.socket = socket;
    new_sock.addr = sock_info->sin_addr.s_addr;
    new_sock.port = sock_info->sin_port;

    if (this->overlap(new_sock)){
        this->returnSystemCall(syscallUUID,-1);
    } else {
        this->sock_segmt_list.push_back(new_sock);	
        this->returnSystemCall(syscallUUID,0);
    }
}

void TCPAssignment::syscall_getsockname(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t *address_len)
{
    struct sockaddr_in *address_in = (struct sockaddr_in *)address;
    std::list<struct sock_segmt>::iterator iter = this->find_sock_segmt_by(socket);
    address_in->sin_family = AF_INET;
    address_in->sin_addr.s_addr = (*iter).addr;
    address_in->sin_port = (*iter).port;
    this->returnSystemCall(syscallUUID, 0);
}

void TCPAssignment::syscall_getpeername(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t *address_len)
{
    struct sockaddr_in *address_in = (struct sockaddr_in *)address;
    std::list<struct sock_segmt>::iterator iter = this->find_sock_segmt_by(socket);
    address_in->sin_family = AF_INET;
    address_in->sin_addr.s_addr = (*iter).addr;
    address_in->sin_port = (*iter).port;
    this->returnSystemCall(syscallUUID, 0);
}


// Helper methods for syscall
std::list<struct sock_segmt>::iterator TCPAssignment::find_sock_segmt_by(int socket)
{
    std::list<struct sock_segmt> sock_segmt_list = this->sock_segmt_list;
    std::list<struct sock_segmt>::iterator iter;

    for(iter=this->sock_segmt_list.begin(); iter != this->sock_segmt_list.end(); ++iter){
        if ((*iter).socket==socket){
            return iter;
        }
    }
    return this->sock_segmt_list.end();
}

bool TCPAssignment::overlap(sock_segmt new_sock)
{
	std::list<struct sock_segmt> sock_segmt_list = this->sock_segmt_list;
    std::list<struct sock_segmt>::iterator iter;

    for(iter=sock_segmt_list.begin(); iter != sock_segmt_list.end(); ++iter){
        bool check_socket = ((*iter).socket == new_sock.socket);
        bool check_sp_ip = ((*iter).addr == 0 || new_sock.addr == 0);
        bool same_ip_port = (((*iter).addr == new_sock.addr) && ((*iter).port == new_sock.port));
        if(check_socket || check_sp_ip || same_ip_port)
            return true;
    }
    return false;
}

}
