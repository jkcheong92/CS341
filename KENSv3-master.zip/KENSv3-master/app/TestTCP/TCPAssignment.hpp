/*
 * E_TCPAssignment.hpp
 *
 *  Created on: 2014. 11. 20.
 *      Author: 근홍
 */

#ifndef E_TCPASSIGNMENT_HPP_
#define E_TCPASSIGNMENT_HPP_


#include <E/Networking/E_Networking.hpp>
#include <E/Networking/E_Host.hpp>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#include <netinet/ip.h>
#include <netinet/in.h>


#include <E/E_TimerModule.hpp>

namespace E
{
// KENS#2
struct hdr {
	uint32_t src_ip;
	uint32_t dst_ip;
	uint16_t src_port;
	uint16_t dst_port;
	uint32_t seqNumber;
	uint32_t ackNumber;
	uint long head_len;
	uint long flag;
	uint16_t rwnd;
	uint16_t checksum;
	uint16_t urgent;
};

struct sock_segmt { 
	int pid;
    int socket;
    long addr;
    short port;
    // KENS#2
    unsigned rwnd;
    unsigned buffer;
    unsigned cwnd;
    unsigned ssthresh;
    int dupAck;
    time_t rtt;
    time_t devtt = 0;
    hdr hdr;
};
// KENS#2
unsigned const MSS = 512;
unsigned const MAX_RCV = (512*100);
unsigned const DEFAULT_RTT = (100/1000);
unsigned const K = 4;
float const ALPHA = (0.125);
float const BETA = (0.25);
unsigned const WRITE_SPEED = (10*1000000);
time_t const TIMEOUT = 1000;

class TCPAssignment : public HostModule, public NetworkModule, public SystemCallInterface, private NetworkLog, private TimerModule
{
private:
	virtual void timerCallback(void* payload) final;
	virtual void syscall_socket(UUID syscallUUID, int pid, int domain, int type);
	virtual void syscall_close(UUID syscallUUID, int pid, int socket);
	virtual void syscall_connect(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t address_len);
	virtual void syscall_listen(UUID syscallUUID, int pid, int socket, int backlog);
	virtual void syscall_accept(UUID syscallUUID, int pid, int socket, struct sockaddr *address, socklen_t *address_len);
	virtual void syscall_bind(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t address_len);
	virtual void syscall_getsockname(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t *address_len);
	virtual void syscall_getpeername(UUID syscallUUID, int pid, int socket, sockaddr *address, socklen_t *address_len);
	virtual std::list<struct sock_segmt>::iterator find_sock_segmt_by(int socket);
	virtual bool overlap(sock_segmt new_sock);
	// KENS#2
	virtual bool find_sock_segmt(int pid, int socket, struct sock_segmt* mSock);
	virtual void syscall_write(UUID syscallUUID, int pid, int socket, void *payload, size_t size);
	virtual void syscall_read(UUID syscallUUID, int pid, int socket, void *payload, size_t size);

public:
	TCPAssignment(Host* host);
	virtual void initialize();
	virtual void finalize();
	virtual ~TCPAssignment();
	std::list<struct sock_segmt> sock_segmt_list;
	// KENS#2
	virtual void writePacket(struct hdr *hdr, void *payload, size_t size);
	virtual void readPacket(struct hdr *hdr, void *payload, size_t size);
	virtual void updateHeader(struct hdr *hdr, size_t size);
	virtual void updateCongestionControls(struct sock_segmt *sock, time_t rtt, bool fast);

protected:
	virtual void systemCallback(UUID syscallUUID, int pid, const SystemCallParameter& param) final;
	virtual void packetArrived(std::string fromModule, Packet* packet) final;
	
};

class TCPAssignmentProvider
{
private:
	TCPAssignmentProvider() {}
	~TCPAssignmentProvider() {}
public:
	static HostModule* allocate(Host* host) { return new TCPAssignment(host); }
};

}


#endif /* E_TCPASSIGNMENT_HPP_ */
